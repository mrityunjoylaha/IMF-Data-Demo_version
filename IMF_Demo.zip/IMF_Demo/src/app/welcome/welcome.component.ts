import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthenticationService, UserDetails} from '../authentication.service'


@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

 
  details:UserDetails

   
  constructor(public auth: AuthenticationService,private router : Router){}

  ngOnInit() {

      // is localstorage is empty -> redirect to login
      if(localStorage.getItem("usertoken") == null){
        alert('Please login First')
      //  this.router.navigateByUrl('')
    }
 
      this.auth.profile().subscribe(
          user => {
              this.details =user
          },
          err => {
              console.error(err)
          }

      )

      setTimeout(() => {
        this.router.navigate(['/applications']);
        },3000);
  }



 
 
}