import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {AuthenticationService, TokenPayload } from '../authentication.service'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)])
  })
  
 showErrorMessage = false;
  credentials: TokenPayload = {
    _id:'',
    Name:'',
    email:'',
    password:'',
    role:''

}
constructor(private auth: AuthenticationService, private router: Router){}


login(){

    this.auth.login(this.credentials).subscribe(
       
        err => {
            // alert('Please enter the correct credentials')
           this.showErrorMessage = true;
            // console.error(err)
           
        }
    )
}

}
